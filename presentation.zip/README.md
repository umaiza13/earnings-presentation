# Quarterly Earnings Presentation

This is a RevealJS-based interactive presentation.

## View online
After pushing to GitHub and enabling Pages:
👉 https://YOUR-USERNAME.github.io/earnings-presentation/

(Add ?v=1, ?v=2 to refresh cache)

## Features
- Email included
- Markdown slide
- Animated fragments
- Code highlighting
- Math formulas
- Speaker notes
